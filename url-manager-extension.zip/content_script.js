/**
 * AI 足迹浏览器扩展 — Content Script
 * 注入到 ai.ocean94.com，检测网站登录态，自动同步 token 到扩展 storage
 */
(function () {
  'use strict';

  var STORAGE_KEY = 'access_token';
  var state = { lastToken: null };

  // 启动时检测
  state.lastToken = localStorage.getItem(STORAGE_KEY);
  console.log('[AI足迹扩展] 启动检测, token=', state.lastToken ? '有(' + state.lastToken.substring(0,10) + '...)' : '无');
  if (state.lastToken) {
    detectAndSend();
  }

  // 跨标签页 storage 事件
  window.addEventListener('storage', function (e) {
    if (e.key === STORAGE_KEY && e.newValue) {
      console.log('[AI足迹扩展] storage事件检测到token');
      saveToken(e.newValue);
    }
  });

  // 轮询兜底
  setInterval(function () {
    var current = localStorage.getItem(STORAGE_KEY);
    if (current && current !== state.lastToken) {
      state.lastToken = current;
      console.log('[AI足迹扩展] 轮询检测到token');
      saveToken(current);
    }
  }, 2000);

  function detectAndSend() {
    var token = localStorage.getItem(STORAGE_KEY);
    if (token) {
      state.lastToken = token;
      saveToken(token);
    }
  }

  function saveToken(token) {
    console.log('[AI足迹扩展] 正在写入chrome.storage, token前10位:', token.substring(0,10));
    chrome.storage.local.set({ token: token }, function () {
      if (chrome.runtime.lastError) {
        console.error('[AI足迹扩展] storage写入失败:', chrome.runtime.lastError.message);
      } else {
        console.log('[AI足迹扩展] token已写入chrome.storage.local ✓');
      }
    });
  }

  // 响应 popup 的 token 查询
  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.type === 'GET_TOKEN') {
      var token = localStorage.getItem(STORAGE_KEY);
      console.log('[AI足迹扩展] popup查询token, 返回:', token ? '有' : '无');
      sendResponse({ token: token || null });
      return true;
    }
  });
})();
