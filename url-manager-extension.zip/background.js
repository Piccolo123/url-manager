/**
 * AI 足迹浏览器扩展 — Service Worker
 * 右键菜单 + 安装引导 + 网站登录态同步
 */

// ====== 安装/更新引导 ======
chrome.runtime.onInstalled.addListener((details) => {
  setUpContextMenu();

  if (details.reason === 'install') {
    chrome.tabs.create({ url: 'chrome://settings/onStartup' });
  }
});

chrome.runtime.onStartup.addListener(() => {
  setUpContextMenu();
});

// ====== 网站登录态同步 ======
// content_script 从 ai.ocean94.com 检测到 token 后发消息过来
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'SAVE_TOKEN' && message.token) {
    chrome.storage.local.set({ token: message.token });
  }
});

// ====== 右键菜单 ======
function setUpContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'save-to-favorites',
      title: '保存到 AI 足迹',
      contexts: ['selection', 'page'],
    });
  });
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'save-to-favorites') return;

  const stored = await chrome.storage.local.get(['token']);
  if (!stored.token) {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'assets/icon-48.png',
      title: 'AI 足迹',
      message: '请先在 ai.ocean94.com 登录，然后就可以右键收藏啦',
    });
    return;
  }

  await chrome.storage.local.set({
    prefill_collection: {
      title: tab.title || '',
      url: tab.url || '',
      note: info.selectionText || '',
    },
  });

  chrome.action.openPopup();
});
