/**
 * AI 足迹浏览器扩展 — Popup 逻辑
 * 登录态同步 → 开 iframe 嵌入网站预览卡片 → postMessage 通信
 */
(function () {
'use strict';

// ====== DOM ======
const loginPanel = document.getElementById('login-panel');
const collectPanel = document.getElementById('collect-panel');
const loginStatus = document.getElementById('login-status');
const loginBtn = document.getElementById('login-btn');
const logoutBtn = document.getElementById('logout-btn');
const previewIframe = document.getElementById('preview-iframe');
const iframeMessage = document.getElementById('iframe-message');

// ====== 状态 ======
let token = null;

// ====== 初始化 ======
document.addEventListener('DOMContentLoaded', init);

async function init() {
  // 1. 监听 storage 变化
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.token && changes.token.newValue) {
      token = changes.token.newValue;
      showCollectPanel();
    } else if (changes.token && !changes.token.newValue) {
      token = null;
      showLoginPanel();
    }
  });

  // 2. 检查存储中的 token
  loginStatus.textContent = '⏳ 读取扩展存储...';
  try {
    var stored = await chrome.storage.local.get(['token']);
    loginStatus.textContent = stored.token
      ? '✓ 存储中有token'
      : '✗ 存储中无token';
  } catch (e) {
    loginStatus.textContent = '✗ 读取存储失败: ' + e.message;
    stored = {};
  }

  if (stored.token) {
    token = stored.token;
    await showCollectPanel();
    return;
  }

  // 3. 扫描标签页读取 token
  loginStatus.textContent = '🔍 扫描打开的 AI 足迹标签页...';
  var result = await tryReadTokenFromTabs();
  if (result && result.token) {
    token = result.token;
    await chrome.storage.local.set({ token: token });
    await showCollectPanel();
    return;
  }

  showLoginPanel();
}

// ====== 面板切换 ======
function showLoginPanel() {
  loginPanel.style.display = 'flex';
  collectPanel.style.display = 'none';
}

async function showCollectPanel() {
  loginPanel.style.display = 'none';
  collectPanel.style.display = 'flex';

  var info = await getCurrentTabInfo();

  // 关键：先设 onload，再设 src，保证处理器在加载完成前注册
  previewIframe.onload = function () {
    sendInitToIframe(info);
  };
  previewIframe.src = 'https://ai.ocean94.com/#/extension-preview-card';
}

function sendInitToIframe(info) {
  if (!token) return;

  previewIframe.contentWindow.postMessage({
    type: 'initCard',
    title: info.title || '',
    url: info.url || '',
    selectedText: info.selectedText || '',
    token: token,
  }, 'https://ai.ocean94.com');
}

// ====== 从 iframe 接收消息 ======
window.addEventListener('message', function (event) {
  // 只接受来自 iframe 的消息
  if (event.source !== previewIframe.contentWindow) return;

  var data = event.data;
  if (!data) return;

  if (data.type === 'saved') {
    iframeMessage.textContent = '✓ 保存成功';
    iframeMessage.style.display = 'block';
    iframeMessage.className = 'iframe-message success';
    setTimeout(function () { window.close(); }, 1500);
  } else if (data.type === 'saveError') {
    iframeMessage.textContent = '✗ ' + (data.message || '保存失败');
    iframeMessage.style.display = 'block';
    iframeMessage.className = 'iframe-message error';
    setTimeout(function () { iframeMessage.style.display = 'none'; }, 5000);
  } else if (data.type === 'close') {
    window.close();
  } else if (data.type === 'resize' && data.height) {
    previewIframe.style.height = data.height + 'px';
  }
});

// ====== 登录 ======
loginBtn.addEventListener('click', function () {
  chrome.tabs.create({ url: 'https://ai.ocean94.com' });
});

// ====== 退出 ======
logoutBtn.addEventListener('click', async function () {
  await chrome.storage.local.remove(['token']);
  token = null;
  showLoginPanel();
});

// ====== 获取当前标签页信息 ======
function getCurrentTabInfo() {
  return new Promise(function (resolve) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs[0];
      if (!tab) {
        resolve({ title: '', url: '', selectedText: '' });
        return;
      }
      var result = {
        title: tab.title || '',
        url: tab.url || '',
        selectedText: '',
      };

      if (tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
        chrome.scripting.executeScript(
          {
            target: { tabId: tab.id },
            func: function () { return window.getSelection() ? window.getSelection().toString() : ''; },
          },
          function (injectionResults) {
            if (injectionResults && injectionResults[0]) {
              result.selectedText = injectionResults[0].result || '';
            }
            resolve(result);
          }
        );
      } else {
        resolve(result);
      }
    });
  });
}

// ====== 从标签页读取 token ======
async function tryReadTokenFromTabs() {
  try {
    var tabs = await chrome.tabs.query({ url: 'https://ai.ocean94.com/*' });
    if (tabs.length === 0) {
      return { error: '未找到已打开的 AI 足迹标签页' };
    }

    // 方案A: executeScript 直接注入读 localStorage
    for (var i = 0; i < tabs.length; i++) {
      try {
        var results = await chrome.scripting.executeScript({
          target: { tabId: tabs[i].id },
          func: function () {
            try { return localStorage.getItem('access_token'); } catch (e) { return null; }
          },
        });
        if (results && results[0] && results[0].result) {
          return { token: results[0].result };
        }
      } catch (e) {}
    }

    // 方案B: sendMessage fallback
    for (var j = 0; j < tabs.length; j++) {
      try {
        var response = await chrome.tabs.sendMessage(tabs[j].id, { type: 'GET_TOKEN' });
        if (response && response.token) {
          return { token: response.token };
        }
      } catch (e) {}
    }

    return { error: '标签页中未检测到 token' };
  } catch (e) {
    return { error: '无法查询标签页' };
  }
}
})();
